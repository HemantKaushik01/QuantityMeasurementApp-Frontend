const BASE_URL = 'http://localhost:8080/api/v1';

// ===== Helper: Get auth headers =====
const getAuthHeaders = () => {
  const token = localStorage.getItem('token');
  const headers = { 'Content-Type': 'application/json' };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
};

// ===== Helper: Handle response =====
const handleResponse = async (response) => {
  if (response.status === 401 || response.status === 403) {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/login';
    throw new Error('Session expired. Please login again.');
  }

  const contentType = response.headers.get('content-type');

  if (!response.ok) {
    let errorMsg = 'Something went wrong';
    if (contentType && contentType.includes('application/json')) {
      const errorData = await response.json();
      errorMsg = errorData.message || errorData.error || errorMsg;
    } else {
      errorMsg = await response.text() || errorMsg;
    }
    throw new Error(errorMsg);
  }

  if (contentType && contentType.includes('application/json')) {
    return response.json();
  }
  return response.text();
};

// ========================================
//  AUTH API
// ========================================

export const authAPI = {
  /**
   * POST /api/v1/auth/login
   * Body: { email, password }
   * Returns: { token, message }
   */
  login: async (email, password) => {
    const response = await fetch(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    return handleResponse(response);
  },

  /**
   * POST /api/v1/auth/signup
   * Body: { username, email, password }
   * Returns: String message
   */
  signup: async (username, email, password) => {
    const response = await fetch(`${BASE_URL}/auth/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, email, password }),
    });
    return handleResponse(response);
  },

  /**
   * POST /api/v1/auth/google
   * Body: { credential }
   * Returns: { token, message }
   */
  googleLogin: async (credential) => {
    const response = await fetch(`${BASE_URL}/auth/google`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ credential }),
    });
    return handleResponse(response);
  },
};

// ========================================
//  QUANTITY MEASUREMENT API
// ========================================

export const quantityAPI = {
  /**
   * POST /api/v1/quantities/convert
   * Returns: { resultString, resultValue }
   * Backend reads targetUnit from thisQuantityDTO
   */
  convert: async (fromValue, fromUnit, toUnit, type) => {
    const body = {
      thisQuantityDTO: {
        value: parseFloat(fromValue),
        unit: fromUnit,
        type: type,
        targetUnit: toUnit,
      },
      thatQuantityDTO: null,
    };
    const response = await fetch(`${BASE_URL}/quantities/convert`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(body),
    });
    return handleResponse(response);
  },

  /**
   * POST /api/v1/quantities/compare
   */
  compare: async (fromValue, fromUnit, toValue, toUnit, type) => {
    const body = {
      thisQuantityDTO: { value: parseFloat(fromValue), unit: fromUnit, type },
      thatQuantityDTO: { value: parseFloat(toValue), unit: toUnit, type },
    };
    const response = await fetch(`${BASE_URL}/quantities/compare`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(body),
    });
    return handleResponse(response);
  },

  /**
   * POST /api/v1/quantities/add
   */
  add: async (fromValue, fromUnit, toValue, toUnit, type) => {
    const body = {
      thisQuantityDTO: { value: parseFloat(fromValue), unit: fromUnit, type },
      thatQuantityDTO: { value: parseFloat(toValue), unit: toUnit, type },
    };
    const response = await fetch(`${BASE_URL}/quantities/add`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(body),
    });
    return handleResponse(response);
  },

  /**
   * POST /api/v1/quantities/subtract
   */
  subtract: async (fromValue, fromUnit, toValue, toUnit, type) => {
    const body = {
      thisQuantityDTO: { value: parseFloat(fromValue), unit: fromUnit, type },
      thatQuantityDTO: { value: parseFloat(toValue), unit: toUnit, type },
    };
    const response = await fetch(`${BASE_URL}/quantities/subtract`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(body),
    });
    return handleResponse(response);
  },

  /**
   * POST /api/v1/quantities/multiply
   */
  multiply: async (fromValue, fromUnit, toValue, toUnit, type) => {
    const body = {
      thisQuantityDTO: { value: parseFloat(fromValue), unit: fromUnit, type },
      thatQuantityDTO: { value: parseFloat(toValue), unit: toUnit, type },
    };
    const response = await fetch(`${BASE_URL}/quantities/multiply`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(body),
    });
    return handleResponse(response);
  },

  /**
   * POST /api/v1/quantities/divide
   */
  divide: async (fromValue, fromUnit, toValue, toUnit, type) => {
    const body = {
      thisQuantityDTO: { value: parseFloat(fromValue), unit: fromUnit, type },
      thatQuantityDTO: { value: parseFloat(toValue), unit: toUnit, type },
    };
    const response = await fetch(`${BASE_URL}/quantities/divide`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(body),
    });
    return handleResponse(response);
  },

  // ===== HISTORY =====

  /**
   * GET /api/v1/quantities/history/operation/{operation}
   * operation: "convert", "compare", "add", "subtract", "multiply", "divide"
   */
  getHistoryByOperation: async (operation) => {
    const response = await fetch(`${BASE_URL}/quantities/history/operation/${operation}`, {
      headers: getAuthHeaders(),
    });
    return handleResponse(response);
  },

  /**
   * GET /api/v1/quantities/history/type/{type}
   * type: "LENGTH", "TEMPERATURE", "VOLUME", "WEIGHT"
   */
  getHistoryByType: async (type) => {
    const response = await fetch(`${BASE_URL}/quantities/history/type/${type}`, {
      headers: getAuthHeaders(),
    });
    return handleResponse(response);
  },

  /**
   * GET /api/v1/quantities/history/errored
   */
  getErroredHistory: async () => {
    const response = await fetch(`${BASE_URL}/quantities/history/errored`, {
      headers: getAuthHeaders(),
    });
    return handleResponse(response);
  },

  /**
   * GET /api/v1/quantities/count/{operation}
   */
  getOperationCount: async (operation) => {
    const response = await fetch(`${BASE_URL}/quantities/count/${operation}`, {
      headers: getAuthHeaders(),
    });
    return handleResponse(response);
  },
};
