import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { FiClock, FiLogOut, FiLogIn } from 'react-icons/fi';
import './Navbar.css';

const Navbar = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const isAuthenticated = !!localStorage.getItem('token');

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  // Don't show navbar on login/signup pages
  if (location.pathname === '/login' || location.pathname === '/signup') {
    return null;
  }

  return (
    <nav className="navbar" id="main-navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-brand" id="brand-link">
          <span className="brand-icon">Q</span>
          <span className="brand-text">Quanment</span>
        </Link>
        <div className="navbar-links">
          <Link 
            to="/history" 
            className={`navbar-link ${location.pathname === '/history' ? 'active' : ''}`}
            id="history-link"
          >
            <FiClock className="nav-icon" />
            <span>History</span>
          </Link>
          {isAuthenticated ? (
            <button className="navbar-link logout-btn" onClick={handleLogout} id="logout-btn">
              <FiLogOut className="nav-icon" />
              <span>Logout</span>
            </button>
          ) : (
            <Link to="/login" className="navbar-link" id="login-link">
              <FiLogIn className="nav-icon" />
              <span>Login</span>
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
